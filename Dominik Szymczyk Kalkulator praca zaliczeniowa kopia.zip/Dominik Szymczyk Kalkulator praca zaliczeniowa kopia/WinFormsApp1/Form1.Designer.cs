﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tbScreen = new TextBox();
            btn7 = new Button();
            btn8 = new Button();
            btn9 = new Button();
            btnDevision = new Button();
            btnAdd = new Button();
            btn4 = new Button();
            btn5 = new Button();
            btn6 = new Button();
            btnSubtracion = new Button();
            btnResult = new Button();
            btn1 = new Button();
            btn2 = new Button();
            btn3 = new Button();
            btnMultiplication = new Button();
            btnClear = new Button();
            btnComma = new Button();
            btn0 = new Button();
            SuspendLayout();
            // 
            // tbScreen
            // 
            tbScreen.Font = new Font("Segoe UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 238);
            tbScreen.Location = new Point(12, 12);
            tbScreen.Name = "tbScreen";
            tbScreen.Size = new Size(409, 43);
            tbScreen.TabIndex = 0;
            tbScreen.TextAlign = HorizontalAlignment.Right;
            // 
            // btn7
            // 
            btn7.Font = new Font("Segoe UI", 20.25F);
            btn7.Location = new Point(12, 61);
            btn7.Name = "btn7";
            btn7.Size = new Size(77, 63);
            btn7.TabIndex = 1;
            btn7.Text = "7";
            btn7.UseVisualStyleBackColor = true;
            btn7.Click += OnBtnNumberClick;
            // 
            // btn8
            // 
            btn8.Font = new Font("Segoe UI", 20.25F);
            btn8.Location = new Point(95, 61);
            btn8.Name = "btn8";
            btn8.Size = new Size(77, 63);
            btn8.TabIndex = 2;
            btn8.Text = "8";
            btn8.UseVisualStyleBackColor = true;
            btn8.Click += OnBtnNumberClick;
            // 
            // btn9
            // 
            btn9.Font = new Font("Segoe UI", 20.25F);
            btn9.Location = new Point(178, 61);
            btn9.Name = "btn9";
            btn9.Size = new Size(77, 63);
            btn9.TabIndex = 3;
            btn9.Text = "9";
            btn9.UseVisualStyleBackColor = true;
            btn9.Click += OnBtnNumberClick;
            // 
            // btnDevision
            // 
            btnDevision.Font = new Font("Segoe UI", 20.25F);
            btnDevision.Location = new Point(261, 61);
            btnDevision.Name = "btnDevision";
            btnDevision.Size = new Size(77, 63);
            btnDevision.TabIndex = 4;
            btnDevision.Text = "/";
            btnDevision.UseVisualStyleBackColor = true;
            btnDevision.Click += OnBtnOperationClick;
            // 
            // btnAdd
            // 
            btnAdd.Font = new Font("Segoe UI", 20.25F);
            btnAdd.Location = new Point(344, 61);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(77, 132);
            btnAdd.TabIndex = 5;
            btnAdd.Text = "+";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += OnBtnOperationClick;
            // 
            // btn4
            // 
            btn4.Font = new Font("Segoe UI", 20.25F);
            btn4.Location = new Point(12, 130);
            btn4.Name = "btn4";
            btn4.Size = new Size(77, 63);
            btn4.TabIndex = 6;
            btn4.Text = "4";
            btn4.UseVisualStyleBackColor = true;
            btn4.Click += OnBtnNumberClick;
            // 
            // btn5
            // 
            btn5.Font = new Font("Segoe UI", 20.25F);
            btn5.Location = new Point(95, 130);
            btn5.Name = "btn5";
            btn5.Size = new Size(77, 63);
            btn5.TabIndex = 7;
            btn5.Text = "5";
            btn5.UseVisualStyleBackColor = true;
            btn5.Click += OnBtnNumberClick;
            // 
            // btn6
            // 
            btn6.Font = new Font("Segoe UI", 20.25F);
            btn6.Location = new Point(178, 130);
            btn6.Name = "btn6";
            btn6.Size = new Size(77, 63);
            btn6.TabIndex = 8;
            btn6.Text = "6";
            btn6.UseVisualStyleBackColor = true;
            btn6.Click += OnBtnNumberClick;
            // 
            // btnSubtracion
            // 
            btnSubtracion.Font = new Font("Segoe UI", 20.25F);
            btnSubtracion.Location = new Point(261, 130);
            btnSubtracion.Name = "btnSubtracion";
            btnSubtracion.Size = new Size(77, 63);
            btnSubtracion.TabIndex = 9;
            btnSubtracion.Text = "-";
            btnSubtracion.UseVisualStyleBackColor = true;
            btnSubtracion.Click += OnBtnOperationClick;
            // 
            // btnResult
            // 
            btnResult.Font = new Font("Segoe UI", 20.25F);
            btnResult.Location = new Point(344, 199);
            btnResult.Name = "btnResult";
            btnResult.Size = new Size(77, 132);
            btnResult.TabIndex = 10;
            btnResult.Text = "=";
            btnResult.UseVisualStyleBackColor = true;
            btnResult.Click += OnBtnResultClick;
            // 
            // btn1
            // 
            btn1.Font = new Font("Segoe UI", 20.25F);
            btn1.Location = new Point(12, 199);
            btn1.Name = "btn1";
            btn1.Size = new Size(77, 63);
            btn1.TabIndex = 11;
            btn1.Text = "1";
            btn1.UseVisualStyleBackColor = true;
            btn1.Click += OnBtnNumberClick;
            // 
            // btn2
            // 
            btn2.Font = new Font("Segoe UI", 20.25F);
            btn2.Location = new Point(95, 199);
            btn2.Name = "btn2";
            btn2.Size = new Size(77, 63);
            btn2.TabIndex = 12;
            btn2.Text = "2";
            btn2.UseVisualStyleBackColor = true;
            btn2.Click += OnBtnNumberClick;
            // 
            // btn3
            // 
            btn3.Font = new Font("Segoe UI", 20.25F);
            btn3.Location = new Point(178, 199);
            btn3.Name = "btn3";
            btn3.Size = new Size(77, 63);
            btn3.TabIndex = 13;
            btn3.Text = "3";
            btn3.UseVisualStyleBackColor = true;
            btn3.Click += OnBtnNumberClick;
            // 
            // btnMultiplication
            // 
            btnMultiplication.Font = new Font("Segoe UI", 20.25F);
            btnMultiplication.Location = new Point(261, 199);
            btnMultiplication.Name = "btnMultiplication";
            btnMultiplication.Size = new Size(77, 63);
            btnMultiplication.TabIndex = 14;
            btnMultiplication.Text = "*";
            btnMultiplication.UseVisualStyleBackColor = true;
            btnMultiplication.Click += OnBtnOperationClick;
            // 
            // btnClear
            // 
            btnClear.Font = new Font("Segoe UI", 20.25F);
            btnClear.Location = new Point(261, 268);
            btnClear.Name = "btnClear";
            btnClear.Size = new Size(77, 63);
            btnClear.TabIndex = 15;
            btnClear.Text = "C";
            btnClear.UseVisualStyleBackColor = true;
            btnClear.Click += OnBtnClearClick;
            // 
            // btnComma
            // 
            btnComma.Font = new Font("Segoe UI", 20.25F);
            btnComma.Location = new Point(178, 268);
            btnComma.Name = "btnComma";
            btnComma.Size = new Size(77, 63);
            btnComma.TabIndex = 16;
            btnComma.Text = ",";
            btnComma.UseVisualStyleBackColor = true;
            btnComma.Click += OnBtnNumberClick;
            // 
            // btn0
            // 
            btn0.Font = new Font("Segoe UI", 20.25F);
            btn0.Location = new Point(12, 268);
            btn0.Name = "btn0";
            btn0.Size = new Size(160, 63);
            btn0.TabIndex = 17;
            btn0.Text = "0";
            btn0.UseVisualStyleBackColor = true;
            btn0.Click += OnBtnNumberClick;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(436, 384);
            Controls.Add(btn0);
            Controls.Add(btnComma);
            Controls.Add(btnClear);
            Controls.Add(btnMultiplication);
            Controls.Add(btn3);
            Controls.Add(btn2);
            Controls.Add(btn1);
            Controls.Add(btnResult);
            Controls.Add(btnSubtracion);
            Controls.Add(btn6);
            Controls.Add(btn5);
            Controls.Add(btn4);
            Controls.Add(btnAdd);
            Controls.Add(btnDevision);
            Controls.Add(btn9);
            Controls.Add(btn8);
            Controls.Add(btn7);
            Controls.Add(tbScreen);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox tbScreen;
        private Button btn7;
        private Button btn8;
        private Button btn9;
        private Button btnDevision;
        private Button btnAdd;
        private Button btn4;
        private Button btn5;
        private Button btn6;
        private Button btnSubtracion;
        private Button btnResult;
        private Button btn1;
        private Button btn2;
        private Button btn3;
        private Button btnMultiplication;
        private Button btnClear;
        private Button btnComma;
        private Button btn0;
    }
}

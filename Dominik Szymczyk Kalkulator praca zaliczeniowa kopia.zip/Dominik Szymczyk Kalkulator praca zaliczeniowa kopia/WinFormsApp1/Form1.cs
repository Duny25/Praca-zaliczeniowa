namespace WinFormsApp1
{
    public enum Operation
    {
        None,
        Addition,
        Subtraction,
        Division,
        Multiplication
    }

    public partial class Form1 : Form
    {
        private string _firstValue;
        private string _secendValue;
        private Operation _currentOperation = Operation.None;
        private bool _isTheResultOnTheScreen;
        public Form1()
        {
            InitializeComponent();
            tbScreen.Text = "0";
        }

        private void OnBtnNumberClick(object sender, EventArgs e)
        {
            var clickedValue = (sender as Button).Text;

            if (tbScreen.Text == "0"&& clickedValue != ",")
                tbScreen.Text = string.Empty;

            if (_isTheResultOnTheScreen)
            {
                _isTheResultOnTheScreen = false;
                tbScreen.Text = string.Empty;

                if (clickedValue == ",")
                    clickedValue = "0,";
                    
                
            }

            tbScreen.Text += clickedValue;
            SetOResultBtnState(true);

            if (_currentOperation != Operation.None)
                _secendValue += clickedValue;
            else
                SetOperationBtnState(true);

        }

        private void OnBtnOperationClick(object sender, EventArgs e)
        {
            _firstValue = tbScreen.Text;

            var operation = (sender as Button).Text;

            _currentOperation = operation switch
            {
                "+" => Operation.Addition,
                "-" => Operation.Subtraction,
                "/" => Operation.Division,
                "*" => Operation.Multiplication,
                _ => Operation.None
            };

            tbScreen.Text += $" {operation} ";


            if (_isTheResultOnTheScreen)
                _isTheResultOnTheScreen = false;

            SetOperationBtnState(false);
            SetOResultBtnState(false);
        }

        private void OnBtnResultClick(object sender, EventArgs e)
        {   
            if (_currentOperation == Operation.None)
                return;

            var firstNumber = double.Parse(_firstValue);
            var secendNumber = double.Parse(_secendValue);

            var result = Calculate(firstNumber, secendNumber);

            tbScreen.Text = result.ToString();
            _secendValue = string.Empty;
            _currentOperation = Operation.None;
            _isTheResultOnTheScreen = true;
            SetOperationBtnState(true);
            SetOResultBtnState(true);


        }
        
        private double Calculate(double firstNumber,  double secondNumber)
        {
            switch (_currentOperation)
            {
                case Operation.None:
                    return firstNumber;
                    
                case Operation.Addition:
                    return firstNumber + secondNumber;
                    
                case Operation.Subtraction:
                    return firstNumber - secondNumber;
                    
                case Operation.Division:
                    if (secondNumber == 0)
                    {
                        MessageBox.Show("NIE MOZNA DZIELIC PRZEZ 0!");
                        return 0;
                    }
                    return firstNumber / secondNumber;
                    
                case Operation.Multiplication:
                    return firstNumber * secondNumber;
                    
            }

            return 0;
        }
        private void OnBtnClearClick(object sender, EventArgs e)
        {
            tbScreen.Text = "0";
            _firstValue = string.Empty;
            _secendValue = string.Empty;
            _currentOperation = Operation.None;
        }

        private void SetOperationBtnState(bool value)
        {
            btnAdd.Enabled = value;
            btnMultiplication.Enabled = value;
            btnDevision.Enabled = value;
            btnSubtracion.Enabled = value;
        }

        private void SetOResultBtnState(bool value)
        {
            btnResult.Enabled = value;
            
        }
    }
}

